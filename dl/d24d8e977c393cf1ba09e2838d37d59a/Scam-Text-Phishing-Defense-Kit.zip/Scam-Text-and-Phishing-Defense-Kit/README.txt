Scam Text & Phishing Defense Kit
Cyber Security 101 · 2026 Edition · v1.0 (built 2026-09-24)
YouTube: https://www.youtube.com/@cybersecurity1012

Thank you for your purchase!

WHAT'S HERE
- Scam-Text-Phishing-Defense-Kit-Guide.pdf
- Family-Scam-Proof-Printables.pdf

TIPS
- PDFs are US Letter. Worksheets are fillable: open in Adobe Acrobat Reader, Apple Preview,
  or a modern browser to type into them, or print and write by hand.
- Official vendor menus change often. If a step doesn't match your screen, use the official
  help page linked next to it.
- Completed recovery/contact worksheets are sensitive. Store them like a passport.

SUPPORT & REFUNDS
Questions, corrections, or a refund within 14 days of purchase: pnsgloballlc@gmail.com

LICENSE
Personal use by the purchaser (Small Business kit: internal use within the purchaser's own
organization). Print as many copies as you need for your household or team. Please do not
resell or redistribute these files.

DISCLAIMER
Educational information, not legal advice. Based on public guidance from the FTC, CISA, NIST,
FBI/IC3 and official vendor help pages as checked in September 2026. Not affiliated with or
endorsed by any government agency or company mentioned.
