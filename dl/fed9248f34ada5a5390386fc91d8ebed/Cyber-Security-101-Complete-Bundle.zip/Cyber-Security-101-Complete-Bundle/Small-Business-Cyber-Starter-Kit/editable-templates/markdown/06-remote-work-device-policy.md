# Remote Work & Device Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Keep company data safe when people work from home, travel, or use mobile devices.

**Scope.** Anyone accessing company systems from outside the office, and any device (company-owned or personal) used for work.

## Devices
- Devices used for work have a screen lock, current updates, security software, and full-disk encryption turned on.
- Personal devices may be used for work only if they meet these requirements and are approved by [NAME / ROLE]. [Optional: enrolled in device management.]
- Lost or stolen devices are reported to [SECURITY CONTACT] immediately — day or night.

## Networks
- Home routers use WPA2 or WPA3 encryption, a changed default admin password, and current firmware.
- On public Wi-Fi, use [VPN / PHONE HOTSPOT]. Turn off automatic connection to public Wi-Fi networks.
- Remote access to company systems requires MFA.

## Physical & privacy
- Don’t leave devices unattended in public. Be aware of people viewing your screen or overhearing calls.
- Family members and guests don’t use work devices.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
