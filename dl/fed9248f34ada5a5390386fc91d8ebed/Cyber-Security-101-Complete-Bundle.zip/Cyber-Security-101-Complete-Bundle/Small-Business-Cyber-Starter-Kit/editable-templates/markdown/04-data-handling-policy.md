# Data Handling, Retention & Disposal Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Keep only the data we need, protect what we keep, and dispose of it securely.

**Scope.** Customer, employee, financial, and business information in any form — paper or electronic.

## Know what we hold
- [NAME / ROLE] keeps an inventory of where sensitive data lives (systems, shared drives, paper files, vendors).

## Protect it
- Sensitive data is stored only in approved systems: [LIST SYSTEMS]. Access is limited to people who need it for their job.
- Laptops, phones, and removable drives holding sensitive data are encrypted. Sensitive data sent outside the company is encrypted.
- Paper files with sensitive information are kept in a locked cabinet or room.

## Keep only what we need
- Retention periods: [DATA TYPE] — [PERIOD]; [DATA TYPE] — [PERIOD]. Check legal, tax, and contract requirements when setting these.
- Don’t collect sensitive data (e.g., full SSNs, full card numbers) unless there’s a business or legal need.

## Dispose securely
- Shred paper with sensitive information before disposal.
- Before a device is sold, recycled, or reassigned, it is factory-reset or wiped with appropriate software. “Delete” alone isn’t enough.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
