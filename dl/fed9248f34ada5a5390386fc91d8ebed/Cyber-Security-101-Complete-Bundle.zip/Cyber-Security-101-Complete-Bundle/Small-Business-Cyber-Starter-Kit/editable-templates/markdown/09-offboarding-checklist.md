# Employee Offboarding Security Checklist

Employee: [NAME] · Role: [ROLE] · Manager: [NAME] · Date: [DATE]

## Before or at departure
- [ ] Schedule access removal for the exact end time (coordinate with HR/manager)
- [ ] Collect devices, keys, badges, and security keys
- [ ] Transfer ownership of files, shared drives, calendars, and email as needed
- [ ] Identify shared accounts or passwords the person knew

## At the end time
- [ ] Disable email and single sign-on accounts; sign out all active sessions
- [ ] Remove from the password manager and all shared vaults
- [ ] Revoke access to banking, payroll, accounting, and admin consoles
- [ ] Remove MFA devices and recovery methods tied to the person
- [ ] Revoke remote access / VPN and any API keys or app passwords
- [ ] Remove from social media admin roles, domain registrar, and website hosting

## Within one week
- [ ] Rotate passwords for shared accounts the person could access
- [ ] Wipe or reimage returned devices before reassignment
- [ ] Set email forwarding/auto-reply per policy, then delete or archive account per retention policy
- [ ] Update the asset & account inventory
- [ ] If departure was contentious: review recent account activity and downloads

Completed by: [NAME] · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice._
