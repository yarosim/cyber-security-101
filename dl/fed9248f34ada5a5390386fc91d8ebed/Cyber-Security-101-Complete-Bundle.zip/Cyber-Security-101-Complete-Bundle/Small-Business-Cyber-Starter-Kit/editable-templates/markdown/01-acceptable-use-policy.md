# Acceptable Use & Security Basics Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Set clear, simple expectations for how everyone at [COMPANY NAME] uses company devices, accounts, and data.

**Scope.** All employees, contractors, and volunteers who use [COMPANY NAME] devices, accounts, networks, or data — on-site or remotely.

## Company accounts & devices
- Use company accounts and devices for company business. Limited personal use is allowed if it doesn’t create risk or interfere with work.
- Never share your account passwords, passkeys, or verification codes with anyone — including coworkers or people claiming to be IT support.
- Lock your screen when you step away. Don’t leave devices unattended in public places.

## Software & downloads
- Install software only from approved sources: [APPROVED APP STORE / IT CONTACT].
- Keep automatic updates turned on. Don’t postpone security updates for more than [NUMBER] days.
- Don’t disable security software or device encryption.

## Email, links & attachments
- Treat unexpected messages that create urgency or ask for credentials, payments, or files with caution.
- Verify unusual requests using a known phone number or in person — never by replying to the message.
- Report suspicious messages to [SECURITY CONTACT] using [REPORT METHOD]. Reporting a mistake quickly is always the right call.

## Data
- Access only the data you need for your role. Don’t copy company or customer data to personal accounts or devices unless approved.
- Don’t post customer, employee, or internal information on social media or public AI tools unless approved by [NAME / ROLE].

## Enforcement
- Questions go to [SECURITY CONTACT]. Violations may result in loss of access and other actions consistent with company policy and applicable law.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
