# Payment & Banking-Change Verification Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Prevent business email compromise (BEC) and invoice fraud, where criminals impersonate executives, vendors, or employees to redirect payments.

**Scope.** Anyone who requests, approves, or sends payments, payroll changes, gift card purchases, or changes to vendor or employee bank details.

## The call-back rule
- Any request to change bank or payment details — for a vendor, customer, or employee direct deposit — must be verified by phone using a number already on file or independently looked up. Never use contact details from the request itself.
- Any unusual or urgent payment request by email, text, or chat — even from a leader — is verified by phone or in person before paying.

## Approvals
- Payments over $[AMOUNT] require approval from two people: [ROLE] and [ROLE].
- New payees are set up by [ROLE] and verified before the first payment.
- The company never pays invoices, fees, or “fines” with gift cards, cryptocurrency, or wire transfers to unverified parties.

## Red flags
- Changed bank details, urgency, secrecy (“don’t tell anyone”), a new email address or slight misspelling of a known domain, or a request to bypass normal approval.

## If a fraudulent payment is sent
- Call the company’s bank immediately at [BANK FRAUD NUMBER] and ask for a recall of the payment.
- Report the incident to the FBI at IC3.gov and notify [SECURITY CONTACT]. Preserve emails and records.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
