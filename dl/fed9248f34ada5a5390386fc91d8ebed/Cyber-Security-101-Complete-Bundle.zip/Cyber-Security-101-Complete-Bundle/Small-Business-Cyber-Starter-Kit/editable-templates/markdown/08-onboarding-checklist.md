# Employee Onboarding Security Checklist

Employee: [NAME] · Role: [ROLE] · Manager: [NAME] · Date: [DATE]

## Before day one
- [ ] Create accounts with least-privilege access for the role (list: [SYSTEMS])
- [ ] Assign a device with updates, security software, encryption, and screen lock configured
- [ ] Add the person to the password manager with only the shared vaults they need
- [ ] Record accounts and devices issued in the asset inventory

## Day one
- [ ] Enroll MFA on email and all company accounts (passkey/security key or authenticator app preferred)
- [ ] Set up the password manager; generate unique passwords for all work accounts
- [ ] Review and sign the security policies (Acceptable Use, Password & MFA, Remote Work, Payment Verification if applicable)
- [ ] Show how to report suspicious messages and incidents: [REPORT METHOD]
- [ ] Explain the call-back rule for payment and bank-detail changes (finance roles)

## First 30 days
- [ ] Complete security awareness training: [TRAINING]
- [ ] Confirm MFA and password manager are in use on every account
- [ ] Confirm backup and file-storage locations are understood
- [ ] Manager check-in: any access that should be added or removed?

Completed by: [NAME] · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice._
