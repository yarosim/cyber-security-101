# Incident First-Hour Card

Incident lead: [NAME] [PHONE] · Backup: [NAME] [PHONE] · IT/security: [CONTACT] · Bank fraud: [NUMBER] · Insurer breach line: [NUMBER]

## 0–5 min — Stay calm. Stop the spread.
- [ ] Disconnect affected devices from the network (unplug Ethernet / turn off Wi-Fi). Don’t power them off — useful evidence may be lost.
- [ ] If a payment was sent to a fraudster: call your bank’s fraud line now to request a recall.

## 5–15 min — Call your response team.
- [ ] Incident lead + backup. IT/security provider.
- [ ] If you have cyber insurance, call the insurer’s breach line — check your policy for notice requirements and approved vendors.

## 15–30 min — Contain the account side.
- [ ] From a clean device, change passwords of compromised accounts and sign out all sessions.
- [ ] Check email forwarding rules and MFA devices for unauthorized changes.
- [ ] Disable accounts of anyone confirmed compromised until reset.

## 30–45 min — Preserve and document.
- [ ] Start the incident log: what happened, when, who noticed, what systems.
- [ ] Save suspicious emails (as attachments), screenshots, ransom notes, and logs. Don’t delete anything.

## 45–60 min — Report and plan next steps.
- [ ] Report to the FBI at IC3.gov or your local FBI field office (ransomware, BEC, intrusions).
- [ ] If personal data may be involved, contact legal counsel about notification obligations; see the FTC’s Data Breach Response guide.
- [ ] Don’t pay a ransom before consulting law enforcement and counsel; paying doesn’t guarantee recovery (FTC).

Report: IC3.gov · FBI field offices: fbi.gov/contact-us/field-offices · FTC data breach guide: ftc.gov/business-guidance/resources/data-breach-response-guide-business

_Educational information, not legal advice._
