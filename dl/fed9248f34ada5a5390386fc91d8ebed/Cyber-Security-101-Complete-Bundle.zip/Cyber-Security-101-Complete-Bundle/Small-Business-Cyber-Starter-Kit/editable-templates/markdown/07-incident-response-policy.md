# Incident Reporting & Response Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Make sure security problems are reported fast and handled consistently, so damage is limited and obligations are met.

**Scope.** Suspected or confirmed security incidents: phishing clicks, account compromise, malware/ransomware, lost devices, data exposure, payment fraud, or vendor breaches.

## Report immediately
- Anyone who suspects an incident reports it right away to [SECURITY CONTACT] at [PHONE] — no blame for good-faith reports.
- Don’t try to investigate or “clean up” on your own. Don’t power off an infected device; disconnect it from the network instead.

## Response lead
- [NAME / ROLE] leads the response, with backup [NAME / ROLE]. They follow the Incident First-Hour Card and keep the incident log.

## Who we call
- IT / security provider: [CONTACT]. Bank: [FRAUD NUMBER]. Cyber insurer breach line: [NUMBER] (check policy notice requirements). Legal counsel: [CONTACT].
- Law enforcement: FBI at IC3.gov or the local FBI field office; local police for theft.

## Notification
- If personal information may be exposed, [NAME / ROLE] consults legal counsel about notification obligations under applicable state and federal law and contracts, following the FTC’s Data Breach Response guide.

## Learn
- After each incident, we record what happened and update policies, training, and controls.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
