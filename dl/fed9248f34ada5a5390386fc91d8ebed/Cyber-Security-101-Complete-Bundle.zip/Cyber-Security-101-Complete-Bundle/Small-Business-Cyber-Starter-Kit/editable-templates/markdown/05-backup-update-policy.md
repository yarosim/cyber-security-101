# Backup & Software Update Policy

Company: [COMPANY NAME] · Policy owner: [NAME / ROLE] · Effective: [DATE] · Next review: [DATE]

**Purpose.** Make sure we can recover from ransomware, hardware failure, or mistakes — and reduce the chance of those happening.

**Scope.** All company computers, phones, servers, network equipment, websites, and cloud services.

## Updates
- Automatic updates are enabled for operating systems, browsers, apps, and security software on all devices.
- [NAME / ROLE] checks monthly for devices or systems that are out of date, including routers, firewalls, and website software.
- Devices that can no longer receive security updates are replaced or isolated by [DATE / TIMEFRAME].

## Backups
- Critical data is backed up [FREQUENCY] to [BACKUP SOLUTION].
- At least one backup copy is kept separate from the main network (offline or in an isolated/immutable cloud location) so ransomware can’t reach it.
- Backups are protected with MFA and restricted access.

## Testing
- [NAME / ROLE] tests restoring files from backup at least every [PERIOD] and records the result.

---
Approved by: [NAME / ROLE] · Signature: ____________ · Date: [DATE]

_Template from the Cyber Security 101 Small Business Cyber Starter Kit. Educational information, not legal advice — adapt to your business, industry regulations, contracts, and applicable law._
