# Editable templates — Small Business Cyber Starter Kit

Two formats of the same templates:

- `word-docx/` — open in Microsoft Word, Google Docs (File → Open → Upload), Apple Pages, or LibreOffice. Placeholders are **highlighted in yellow**.
- `markdown/` — plain text for wikis, Notion, Git repos, or any text editor. Placeholders look like `[COMPANY NAME]`.

## How to customize
1. Replace every `[BRACKETED FIELD]` (search for `[`).
2. Delete rules that don't apply; add anything your industry, contracts, or insurer require.
3. Set a policy owner, effective date, and review date. Approve and sign.
4. Share with staff and collect the acknowledgment form (in the PDF).

## Files
| # | Template |
|---|---|
| 01 | Acceptable Use & Security Basics Policy |
| 02 | Password, Passkey & MFA Policy |
| 03 | Payment & Banking-Change Verification Policy |
| 04 | Data Handling, Retention & Disposal Policy |
| 05 | Backup & Software Update Policy |
| 06 | Remote Work & Device Policy |
| 07 | Incident Reporting & Response Policy |
| 08 | Employee Onboarding Security Checklist |
| 09 | Employee Offboarding Security Checklist |
| 10 | Incident First-Hour Card |

_Educational information, not legal advice. Licensed for internal use within the purchaser's own organization; please don't resell or redistribute._
